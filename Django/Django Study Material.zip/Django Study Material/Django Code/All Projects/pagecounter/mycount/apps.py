from django.apps import AppConfig


class MycountConfig(AppConfig):
    name = 'mycount'
